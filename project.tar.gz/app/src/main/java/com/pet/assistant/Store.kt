package com.pet.assistant

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    private fun plain(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("pet", Context.MODE_PRIVATE)

    private fun secure(ctx: Context): SharedPreferences {
        val app = ctx.applicationContext
        val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            app,
            "pet_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun apiKey(ctx: Context): String =
        try { secure(ctx).getString("api_key", "") ?: "" } catch (e: Exception) { "" }

    fun setApiKey(ctx: Context, key: String) {
        secure(ctx).edit().putString("api_key", key.trim()).apply()
    }

    fun model(ctx: Context): String =
        plain(ctx).getString("model", "openai/gpt-oss-120b") ?: "openai/gpt-oss-120b"

    fun setModel(ctx: Context, model: String) {
        plain(ctx).edit().putString("model", model.trim()).apply()
    }

    fun enabled(ctx: Context): Boolean = plain(ctx).getBoolean("enabled", false)

    fun setEnabled(ctx: Context, value: Boolean) {
        plain(ctx).edit().putBoolean("enabled", value).apply()
    }

    @Synchronized
    fun log(ctx: Context, text: String) {
        val p = plain(ctx)
        val arr = JSONArray(p.getString("log", "[]"))
        val stamp = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())
        arr.put("$stamp  $text")
        while (arr.length() > 200) arr.remove(0)
        p.edit().putString("log", arr.toString()).apply()
    }

    fun logLines(ctx: Context): List<String> {
        val arr = JSONArray(plain(ctx).getString("log", "[]"))
        val out = ArrayList<String>()
        for (i in arr.length() - 1 downTo 0) out.add(arr.getString(i))
        return out
    }

    @Synchronized
    fun addTodo(ctx: Context, title: String, due: String) {
        val p = plain(ctx)
        val arr = JSONArray(p.getString("todos", "[]"))
        arr.put(JSONObject().put("title", title).put("due", due).put("done", false))
        p.edit().putString("todos", arr.toString()).apply()
    }
}
