package com.pet.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            Store.enabled(context) &&
            Settings.canDrawOverlays(context)
        ) {
            try {
                context.startForegroundService(Intent(context, PetService::class.java))
            } catch (e: Exception) {
                Store.log(context, "boot start failed: ${e.message}")
            }
        }
    }
}
