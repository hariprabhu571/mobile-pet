package com.pet.assistant

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZoneOffset

class Tools(
    private val ctx: Context,
    private val approve: suspend (String, String) -> Boolean,
    private val onLaunch: () -> Unit
) {
    suspend fun execute(name: String, input: JSONObject): String {
        Store.log(ctx, "tool: $name")
        return try {
            when (name) {
                "add_todo" -> addTodo(input)
                "add_reminder" -> addReminder(input)
                "read_health" -> readHealth(input)
                "draft_email" -> draftEmail(input)
                "send_whatsapp" -> sendWhatsapp(input)
                else -> "Unknown tool"
            }
        } catch (e: Exception) {
            Store.log(ctx, "error in $name: ${e.message}")
            "Error: ${e.message}"
        }
    }

    private suspend fun addTodo(i: JSONObject): String {
        val title = i.getString("title")
        val due = i.optString("due", "")
        Store.addTodo(ctx, title, due)
        val cal = withContext(Dispatchers.IO) { addToCalendar(title, due) }
        return "Todo saved. $cal"
    }

    private suspend fun addReminder(i: JSONObject): String {
        val title = i.getString("title")
        val at = i.getString("remind_at")
        Store.addTodo(ctx, title, at)
        val cal = withContext(Dispatchers.IO) { addToCalendar(title, at) }
        return "Reminder set. $cal"
    }

    private suspend fun readHealth(i: JSONObject): String {
        val days = i.optInt("days", 1).coerceIn(1, 7)
        val arr = i.optJSONArray("metrics")
        val metrics = mutableSetOf<String>()
        if (arr != null) {
            for (k in 0 until arr.length()) metrics.add(arr.getString(k))
        }
        if (metrics.isEmpty()) metrics.addAll(listOf("steps", "heart_rate", "distance", "calories", "workouts"))
        val span = if (days == 1) "today" else "the last $days days"
        val ok = approve(
            "Health check",
            "Read ${metrics.joinToString(", ")} for $span?\nThe values will be sent to the AI to answer you."
        )
        Store.log(ctx, "health read approved=$ok")
        if (!ok) return "The user rejected this request. Do not retry."
        return HealthRepo.read(ctx, days, metrics)
    }

    private suspend fun draftEmail(i: JSONObject): String {
        val to = i.optString("to", "")
        val subject = i.optString("subject", "")
        val body = i.optString("body", "")
        val ok = approve("Open this email in Gmail?", "To: $to\nSubject: $subject\n\n$body")
        Store.log(ctx, "email approved=$ok")
        if (!ok) return "The user rejected the email. Do not retry."
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
            if (to.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        onLaunch()
        try {
            intent.setPackage("com.google.android.gm")
            ctx.startActivity(intent)
        } catch (e: Exception) {
            intent.setPackage(null)
            ctx.startActivity(intent)
        }
        return "Gmail compose screen opened. The user still has to tap Send."
    }

    private suspend fun sendWhatsapp(i: JSONObject): String {
        val phone = i.optString("phone", "").filter { it.isDigit() }
        val message = i.optString("message", "")
        val who = if (phone.isBlank()) "(you choose the contact in WhatsApp)" else "+$phone"
        val ok = approve("Open this WhatsApp message?", "To: $who\n\n$message")
        Store.log(ctx, "whatsapp approved=$ok")
        if (!ok) return "The user rejected the message. Do not retry."
        val url = if (phone.isBlank()) "https://wa.me/?text=${Uri.encode(message)}"
        else "https://wa.me/$phone?text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        onLaunch()
        try {
            intent.setPackage("com.whatsapp")
            ctx.startActivity(intent)
        } catch (e: Exception) {
            intent.setPackage(null)
            ctx.startActivity(intent)
        }
        return "WhatsApp opened with the message ready. The user still has to tap Send."
    }

    private fun findCalendarId(): Long? {
        val proj = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.IS_PRIMARY,
            CalendarContract.Calendars.ACCOUNT_TYPE
        )
        var best: Long? = null
        var bestScore = -1
        val cursor = ctx.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            proj,
            "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= 500",
            null,
            null
        )
        cursor?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val primary = c.getInt(1) == 1
                val google = c.getString(2) == "com.google"
                val score = (if (google) 1 else 0) + (if (primary) 2 else 0)
                if (score > bestScore) {
                    best = id
                    bestScore = score
                }
            }
        }
        return best
    }

    private fun parseMillis(s: String): Long {
        return try {
            LocalDateTime.parse(s).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        } catch (e: Exception) {
            OffsetDateTime.parse(s).toInstant().toEpochMilli()
        }
    }

    private fun addToCalendar(title: String, whenIso: String): String {
        if (ctx.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            return "Calendar permission is missing, so it is only in the app list."
        }
        val calId = findCalendarId() ?: return "No calendar found on the phone."
        val v = ContentValues()
        v.put(CalendarContract.Events.CALENDAR_ID, calId)
        v.put(CalendarContract.Events.TITLE, title)
        val timed = whenIso.length > 10
        if (timed) {
            val start = parseMillis(whenIso)
            v.put(CalendarContract.Events.DTSTART, start)
            v.put(CalendarContract.Events.DTEND, start + 30L * 60L * 1000L)
            v.put(CalendarContract.Events.EVENT_TIMEZONE, ZoneId.systemDefault().id)
            v.put(CalendarContract.Events.HAS_ALARM, 1)
        } else {
            val day = if (whenIso.isBlank()) LocalDate.now() else LocalDate.parse(whenIso)
            val s = day.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
            v.put(CalendarContract.Events.DTSTART, s)
            v.put(CalendarContract.Events.DTEND, s + 24L * 3600L * 1000L)
            v.put(CalendarContract.Events.ALL_DAY, 1)
            v.put(CalendarContract.Events.EVENT_TIMEZONE, "UTC")
        }
        val uri = ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v)
            ?: return "Could not write to the calendar."
        if (timed) {
            val r = ContentValues()
            r.put(CalendarContract.Reminders.EVENT_ID, ContentUris.parseId(uri))
            r.put(CalendarContract.Reminders.MINUTES, 0)
            r.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
            ctx.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, r)
        }
        return "Added to your calendar."
    }
}
