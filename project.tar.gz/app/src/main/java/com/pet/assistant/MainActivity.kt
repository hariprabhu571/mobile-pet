package com.pet.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val scope = MainScope()
    private val refreshers = mutableListOf<() -> Unit>()
    private lateinit var healthLauncher: ActivityResultLauncher<Set<String>>
    private var healthOk = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        healthLauncher = registerForActivityResult(
            PermissionController.createRequestPermissionResultContract()
        ) { refresh() }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(20), dp(20), dp(40))
        val scroll = ScrollView(this)
        scroll.addView(col)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(scroll)

        text(col, "Pet setup", 26f)
        text(col, "Do these steps from top to bottom. Each one turns ✅ when done.", 14f)

        row(col, "1. Display over other apps", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        row(col, "2. Notifications", { has(Manifest.permission.POST_NOTIFICATIONS) }) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        row(col, "3. Microphone (only used when you tap 🎤)", { has(Manifest.permission.RECORD_AUDIO) }) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
        }
        row(col, "4. Calendar (todos and reminders go to Google Calendar)", {
            has(Manifest.permission.READ_CALENDAR) && has(Manifest.permission.WRITE_CALENDAR)
        }) {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 3)
        }
        row(col, "5. Health Connect (steps, heart rate, distance, calories, workouts. No sleep.)", { healthOk }) {
            if (!HealthRepo.available(this)) {
                Toast.makeText(this, "Health Connect is not available. Install or update it from Play Store.", Toast.LENGTH_LONG).show()
            } else {
                healthLauncher.launch(HealthRepo.requestPermissions)
            }
        }
        row(col, "6. Battery: allow Pet to run in background", {
            getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        }) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            Toast.makeText(this, "Find Pet in the list and choose Don't optimize / Unrestricted.", Toast.LENGTH_LONG).show()
        }
        text(
            col,
            "Samsung tip: Settings > Battery > Background usage limits > Never sleeping apps > add Pet. Also App info > Pet > Battery > Unrestricted.",
            12f
        )

        text(col, "7. AI key", 16f)
        val keyBox = EditText(this)
        keyBox.hint = "Paste your Groq API key (gsk_...)"
        keyBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        col.addView(keyBox)
        val modelBox = EditText(this)
        modelBox.setText(Store.model(this))
        modelBox.hint = "Model name, e.g. openai/gpt-oss-120b"
        col.addView(modelBox)
        val keyStatus = TextView(this)
        col.addView(keyStatus)
        refreshers.add {
            keyStatus.text = if (Store.apiKey(this).isNotBlank()) "✅ Key saved (hidden)" else "⬜ No key saved yet"
        }
        val save = Button(this)
        save.text = "Save key and model"
        save.setOnClickListener {
            if (keyBox.text.isNotBlank()) Store.setApiKey(this, keyBox.text.toString())
            if (modelBox.text.isNotBlank()) Store.setModel(this, modelBox.text.toString())
            keyBox.setText("")
            refresh()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        col.addView(save)

        text(col, "8. Wake the pet", 16f)
        val start = Button(this)
        start.text = "Start Pet"
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Do step 1 first.", Toast.LENGTH_LONG).show()
            } else {
                Store.setEnabled(this, true)
                startForegroundService(Intent(this, PetService::class.java))
                Toast.makeText(this, "Pet started. Go to your home screen.", Toast.LENGTH_LONG).show()
            }
        }
        col.addView(start)
        val stop = Button(this)
        stop.text = "Stop Pet"
        stop.setOnClickListener {
            Store.setEnabled(this, false)
            stopService(Intent(this, PetService::class.java))
        }
        col.addView(stop)

        val histBtn = Button(this)
        histBtn.text = "Show / hide action history"
        val hist = TextView(this)
        hist.visibility = View.GONE
        hist.textSize = 12f
        histBtn.setOnClickListener {
            if (hist.visibility == View.VISIBLE) {
                hist.visibility = View.GONE
            } else {
                hist.text = Store.logLines(this).joinToString("\n").ifBlank { "Nothing yet." }
                hist.visibility = View.VISIBLE
            }
        }
        col.addView(histBtn)
        col.addView(hist)
    }

    private fun text(parent: LinearLayout, s: String, size: Float) {
        val tv = TextView(this)
        tv.text = s
        tv.textSize = size
        tv.setPadding(0, dp(10), 0, dp(4))
        parent.addView(tv)
    }

    private fun row(parent: LinearLayout, label: String, done: () -> Boolean, action: () -> Unit) {
        val tv = TextView(this)
        tv.textSize = 15f
        tv.setPadding(0, dp(12), 0, 0)
        val btn = Button(this)
        btn.text = "Open / grant"
        btn.setOnClickListener { action() }
        parent.addView(tv)
        parent.addView(btn)
        refreshers.add { tv.text = (if (done()) "✅ " else "⬜ ") + label }
    }

    private fun refresh() {
        scope.launch {
            healthOk = try { HealthRepo.granted(this@MainActivity) } catch (e: Exception) { false }
            refreshers.forEach { it() }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
