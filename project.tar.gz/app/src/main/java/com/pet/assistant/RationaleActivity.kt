package com.pet.assistant

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class RationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "Pet reads your steps, heart rate, distance, active calories and workouts from Health Connect only when you tap Approve on a card. Sleep data is never requested. Values are sent to the AI service you configured, only to answer your question."
        tv.textSize = 16f
        tv.setPadding(48, 120, 48, 48)
        setContentView(tv)
    }
}
