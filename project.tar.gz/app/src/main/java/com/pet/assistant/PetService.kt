package com.pet.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

class PetService : Service() {
    private lateinit var wm: WindowManager
    private var petView: ImageView? = null
    private lateinit var petParams: WindowManager.LayoutParams
    private var chatRoot: LinearLayout? = null
    private lateinit var chatParams: WindowManager.LayoutParams
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var approvalBar: LinearLayout
    private lateinit var approvalText: TextView
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var bounce: ObjectAnimator? = null
    private var speech: SpeechRecognizer? = null
    private var pending: CompletableDeferred<Boolean>? = null
    private var busy = false
    private var chatVisible = false
    private lateinit var brain: Brain

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> bounce?.pause()
                Intent.ACTION_SCREEN_ON -> bounce?.resume()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        brain = Brain(this, Tools(this, this::askApproval, this::hideChat))
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "pet"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "Pet", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Pet is awake")
            .setContentText("Tap to open settings")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (petView == null) addPet()
        return START_STICKY
    }

    private fun addPet() {
        val iv = ImageView(this)
        iv.setImageResource(R.drawable.pet)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setPadding(0, dp(8), 0, 0)
        val p = WindowManager.LayoutParams(
            dp(80), dp(145),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = resources.displayMetrics.widthPixels - dp(80)
        p.y = dp(300)
        petParams = p
        petView = iv

        iv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY
                        ox = petParams.x; oy = petParams.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt()
                        val dy = (e.rawY - sy).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            petParams.x = ox + dx
                            petParams.y = oy + dy
                            wm.updateViewLayout(iv, petParams)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) toggleChat() else snapToEdge()
                    }
                }
                return true
            }
        })
        wm.addView(iv, p)

        val a = ObjectAnimator.ofFloat(iv, "translationY", 0f, -dp(6).toFloat())
        a.duration = 900
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.start()
        bounce = a
    }

    private fun snapToEdge() {
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val target = if (petParams.x + petParams.width / 2 < screenW / 2) 0 else screenW - petParams.width
        petParams.y = petParams.y.coerceIn(0, screenH - petParams.height)
        val anim = ValueAnimator.ofInt(petParams.x, target)
        anim.duration = 160
        anim.addUpdateListener {
            petParams.x = it.animatedValue as Int
            petView?.let { v -> wm.updateViewLayout(v, petParams) }
        }
        anim.start()
    }

    private fun buildChat() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(10), dp(12), dp(10))
        val bg = GradientDrawable()
        bg.setColor(0xF5FFFFFF.toInt())
        bg.cornerRadius = dp(18).toFloat()
        root.background = bg

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Pet"
        title.textSize = 16f
        title.setTextColor(0xFF111111.toInt())
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = Button(this)
        close.text = "✕"
        close.setOnClickListener { hideChat() }
        header.addView(close)
        root.addView(header)

        logView = TextView(this)
        logView.textSize = 14f
        logView.setTextColor(0xFF222222.toInt())
        logView.text = "Hi! Ask me to add a todo, set a reminder, check your steps, or draft a message."
        logScroll = ScrollView(this)
        logScroll.addView(logView)
        root.addView(logScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170)))

        approvalText = TextView(this)
        approvalText.textSize = 14f
        approvalText.setTextColor(0xFF7A1F00.toInt())
        val approve = Button(this)
        approve.text = "Approve"
        approve.setOnClickListener { resolve(true) }
        val reject = Button(this)
        reject.text = "Reject"
        reject.setOnClickListener { resolve(false) }
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.addView(approve)
        btns.addView(reject)
        approvalBar = LinearLayout(this)
        approvalBar.orientation = LinearLayout.VERTICAL
        approvalBar.visibility = View.GONE
        approvalBar.addView(approvalText)
        approvalBar.addView(btns)
        root.addView(approvalBar)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "Type a message"
        input.setTextColor(0xFF111111.toInt())
        input.setHintTextColor(0xFF888888.toInt())
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setOnEditorActionListener { _, _, _ ->
            send(input.text.toString())
            true
        }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val mic = Button(this)
        mic.text = "🎤"
        mic.setOnClickListener { startListening() }
        row.addView(mic)
        val sendBtn = Button(this)
        sendBtn.text = "Send"
        sendBtn.setOnClickListener { send(input.text.toString()) }
        row.addView(sendBtn)
        root.addView(row)

        val screenW = resources.displayMetrics.widthPixels
        val p = WindowManager.LayoutParams(
            screenW - dp(24), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        p.y = dp(40)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        chatParams = p
        chatRoot = root
    }

    private fun toggleChat() {
        if (chatVisible) hideChat() else showChat()
    }

    private fun showChat() {
        if (chatRoot == null) buildChat()
        if (!chatVisible) {
            wm.addView(chatRoot, chatParams)
            chatVisible = true
        }
    }

    private fun hideChat() {
        if (chatVisible) {
            chatRoot?.let { wm.removeView(it) }
            chatVisible = false
        }
        if (pending != null) resolve(false)
    }

    private fun appendLog(s: String) {
        logView.append("\n$s")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        input.setText("")
        appendLog("You: $t")
        appendLog("…")
        busy = true
        scope.launch {
            val reply = try {
                brain.ask(t)
            } catch (e: Exception) {
                "Sorry, that failed: ${e.message}"
            }
            appendLog("Pet: $reply")
            busy = false
        }
    }

    private suspend fun askApproval(title: String, body: String): Boolean {
        showChat()
        val d = CompletableDeferred<Boolean>()
        pending = d
        approvalText.text = "$title\n$body"
        approvalBar.visibility = View.VISIBLE
        return d.await()
    }

    private fun resolve(ok: Boolean) {
        if (::approvalBar.isInitialized) approvalBar.visibility = View.GONE
        pending?.complete(ok)
        pending = null
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            appendLog("Pet: Please grant the microphone permission in the Pet app.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            appendLog("Pet: Speech recognition is not available on this phone.")
            return
        }
        speech?.destroy()
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { appendLog("🎤 Listening…") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { appendLog("Pet: I didn't catch that.") }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val t = list?.firstOrNull()
                if (t != null) send(t)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        sr.startListening(i)
        speech = sr
    }

    override fun onDestroy() {
        bounce?.cancel()
        speech?.destroy()
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        if (chatVisible) chatRoot?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        petView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        petView = null
        scope.cancel()
        super.onDestroy()
    }
}
