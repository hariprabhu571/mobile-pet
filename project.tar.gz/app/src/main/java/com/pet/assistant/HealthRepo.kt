package com.pet.assistant

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

// Sleep data is intentionally never requested or read.
object HealthRepo {
    val corePermissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class)
    )

    val requestPermissions: Set<String> =
        corePermissions + "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND"

    fun available(ctx: Context): Boolean =
        HealthConnectClient.getSdkStatus(ctx) == HealthConnectClient.SDK_AVAILABLE

    suspend fun granted(ctx: Context): Boolean {
        if (!available(ctx)) return false
        val g = HealthConnectClient.getOrCreate(ctx).permissionController.getGrantedPermissions()
        return g.containsAll(corePermissions)
    }

    private fun f1(v: Double): String = String.format(Locale.US, "%.1f", v)

    suspend fun read(ctx: Context, days: Int, metrics: Set<String>): String {
        if (!available(ctx)) return "Health Connect is not available on this phone."
        val client = HealthConnectClient.getOrCreate(ctx)
        val granted = client.permissionController.getGrantedPermissions()
        if (!granted.containsAll(corePermissions)) {
            return "Health permissions are not granted. Ask the user to open the Pet app and grant Health access."
        }
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now().minusDays((days - 1).toLong()).atStartOfDay(zone).toInstant()
        val range = TimeRangeFilter.between(start, Instant.now())
        val sb = StringBuilder()
        sb.append(if (days == 1) "Period: today so far.\n" else "Period: last $days days including today.\n")

        if ("steps" in metrics) {
            val r = client.aggregate(
                AggregateRequest(metrics = setOf(StepsRecord.COUNT_TOTAL), timeRangeFilter = range)
            )
            sb.append("Steps: ${r[StepsRecord.COUNT_TOTAL] ?: 0}\n")
        }
        if ("heart_rate" in metrics) {
            val r = client.aggregate(
                AggregateRequest(
                    metrics = setOf(HeartRateRecord.BPM_AVG, HeartRateRecord.BPM_MIN, HeartRateRecord.BPM_MAX),
                    timeRangeFilter = range
                )
            )
            val avg = r[HeartRateRecord.BPM_AVG]
            if (avg == null) {
                sb.append("Heart rate: no data.\n")
            } else {
                sb.append("Heart rate (bpm): avg $avg, min ${r[HeartRateRecord.BPM_MIN]}, max ${r[HeartRateRecord.BPM_MAX]}\n")
            }
        }
        if ("distance" in metrics) {
            val r = client.aggregate(
                AggregateRequest(metrics = setOf(DistanceRecord.DISTANCE_TOTAL), timeRangeFilter = range)
            )
            val m = r[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0
            sb.append("Distance: ${f1(m / 1000.0)} km\n")
        }
        if ("calories" in metrics) {
            val r = client.aggregate(
                AggregateRequest(
                    metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
                    timeRangeFilter = range
                )
            )
            val kcal = r[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0
            sb.append("Active calories: ${f1(kcal)} kcal\n")
        }
        if ("workouts" in metrics) {
            val res = client.readRecords(
                ReadRecordsRequest(recordType = ExerciseSessionRecord::class, timeRangeFilter = range)
            )
            if (res.records.isEmpty()) {
                sb.append("Workouts: none recorded.\n")
            } else {
                sb.append("Workouts: ${res.records.size}\n")
                for (rec in res.records.take(10)) {
                    val mins = Duration.between(rec.startTime, rec.endTime).toMinutes()
                    sb.append("- ${rec.title ?: "type ${rec.exerciseType}"}: $mins min\n")
                }
            }
        }
        return sb.toString()
    }
}
